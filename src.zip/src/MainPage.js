import React, { Component } from 'react';

class MainPage extends Component {
    constructor(props) {
        super(props)
        this.state = {
            page : props.page, 
            connexion : false }
        this.getConnected = this.getConnected.bind(this);
        this.setLogout = this.setLogout.bind(this);
    }

    getconnected(){
        this.state.page = "murdetweet";
        this.state.connexion = true;
        return this.state;
    }

    setLogout() {
        this.state.page = "connexion";
        this.state.connexion = false;
    }
    render() {
        return (
            <div></div>
        );
    }

}

    
export default MainPage;